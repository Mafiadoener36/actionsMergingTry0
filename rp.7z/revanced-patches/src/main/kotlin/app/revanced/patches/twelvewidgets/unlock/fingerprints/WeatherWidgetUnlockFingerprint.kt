package app.revanced.patches.twelvewidgets.unlock.fingerprints

object WeatherWidgetUnlockFingerprint : MethodUnlockFingerprint("WeatherWidgetConfigureActivity")
