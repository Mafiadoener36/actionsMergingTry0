package app.revanced.patches.twelvewidgets.unlock.fingerprints

object CalendarWideDayEventsWidgetUnlockFingerprint :
    MethodUnlockFingerprint("CalendarWideDayEventsWidgetConfigureActivity")
